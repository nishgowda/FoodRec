//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

PlaygroundSupport.PlaygroundPage.current.liveView = ViewController()


